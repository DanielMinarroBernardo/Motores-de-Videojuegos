#pragma once


struct vec2 {

	float x;
	float y;

	vec2(float x, float y);
	vec2& operator+(vec2 otro);
	float& operator[] (int i);

};


struct vec3 {

	float x;
	float y;
	float z;

	vec3(float x, float y, float z);
	vec3& operator+(vec3 otro);
	float& operator[] (int i);
	float pordEscalar(vec3 otro);
	vec3 pordVectorial(vec3 otro);
};
