#include <iostream>
#include "vectors.h"



int main() {

	vec2 a (2,1);
	vec2 b = { 3,1 };
	vec2 c = a + b;
	
	std::cout << c[0];


	vec3 a(2, 2, 5);
	vec3 b = { 3,3,5 };
	//vec3 c = a + b;

	std::cout << c[2];

}