#include "vectors.h"
#include "figuras.h"


int main() {

	Circulo c (1, Punto2D(4, 4));
	Rectangulo r (Punto2D(2, 4), Punto2D(5, 5));
	


	//std::cout << c.colision(r) << std::endl;
	std::cout << r.colision(c) << std::endl;
}