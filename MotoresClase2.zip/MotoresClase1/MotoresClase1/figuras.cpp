
#include "figuras.h"

const float Linea2D::longitud()
{
	return vec2::moduloVec2(this->final - this->inicio);
}

bool Ciruclo::colision(Ciruclo c2)
{
	/*float distanciacentros = vec2::moduloVec2(c2.
	float radio1 = this->radio;
	float radio2 = c2.radio;
	if (distanciacentros < radio1 + radio2){
		return true;
	}
	else {
		return false;
	}*/

	return this->radio + c2.radio < 
		vec2::moduloVec2(this->centro - c2.centro);
}

bool Rectangulo::colision(Rectangulo r) {
	return this->pos.x > r.pos.x + r.diagonal.x && 
		this->pos.y > r.pos.y + r.diagonal.y;
}