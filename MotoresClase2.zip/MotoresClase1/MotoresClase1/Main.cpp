#include "vectors.h"
#include "figuras.h"


int main() {

	vec2 a (6,0);
	vec2 b(0, 0);
	std::cout << a.angulo(b);

	Linea2D linea_ejemplo(Punto2D(1, 2), Punto2D(4, 6));
	std::cout << linea_ejemplo.longitud() << std::endl;
}