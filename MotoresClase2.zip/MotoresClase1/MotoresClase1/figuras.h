#pragma once
#include "vectors.h"

//Quiere decir que al ser lo mismo se usa el alias de Punto2D en vez de vec2
typedef vec2 Punto2D;


// Defino la clase linea2d
class Linea2D {
	Punto2D inicio;
	Punto2D final;

public:
	Linea2D(Punto2D inicio, Punto2D final) :inicio(inicio), final(final) {}

	const float longitud();
	//const double  angulo();
};


//Defino la clase de Ciruclo
class Ciruclo {
	Punto2D centro;
	float radio;

public:
	Ciruclo(float radio):radio(radio){}
	Ciruclo(float radio,Punto2D centro) :radio(radio),centro(centro) {}

	bool colision(Ciruclo c2);
};


//Defino la clase de Rectangulo
class Rectangulo {
	Punto2D pos;
	vec2 diagonal;

public:

	Rectangulo(Punto2D pos,vec2 diagonal):pos(pos),diagonal(diagonal){}
	Rectangulo(vec2 diagonal) :pos(Punto2D(0,0)), diagonal(diagonal) {}

	bool colision(Rectangulo r);
};